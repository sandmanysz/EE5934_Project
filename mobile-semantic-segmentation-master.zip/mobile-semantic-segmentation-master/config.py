IMG_DIR = 'data/raw'

